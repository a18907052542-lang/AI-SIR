#!/usr/bin/env python3
"""
脚本 03: 倾向得分匹配 (论文 Section 3.5 + 4.2.1)

  - 7 维创作者协变量构建
  - Logistic 回归倾向得分
  - 1:1 最近邻匹配 (caliper = 0.05 SD)
  - 协变量平衡检验 (SMD < 0.10)
  - PSM-adjusted α 与 95% CI
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src.psm import run_psm


if __name__ == "__main__":
    run_psm()
    print("\n✓ Section 3.5 + 4.2.1 (PSM) 完成")
