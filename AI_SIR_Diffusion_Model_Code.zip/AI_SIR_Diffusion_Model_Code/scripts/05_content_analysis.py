#!/usr/bin/env python3
"""脚本 05: 按内容类型分析 (论文 Section 4.3.1 + Table 6)"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src.content_analysis import run_content_analysis

if __name__ == "__main__":
    run_content_analysis()
    print("\n✓ Section 4.3.1 (Content Type Analysis) 完成")
