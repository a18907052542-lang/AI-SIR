#!/usr/bin/env python3
"""
脚本 04: 主估计 (论文 Section 4.2.2)

  - 加载 I(t) 时间序列
  - 用 NLS Trust-Region-Reflective 拟合 β、γ
  - 计算 R₀、R²、RMSE
  - 诊断: Durbin-Watson, Ljung-Box Q(20), 条件数
  - 输出 Table 5
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import numpy as np
import pandas as pd

from src.data_loader import load_videos, build_It_from_videos
from src.parameter_estimation import fit_ai_sir, durbin_watson, ljung_box
from src.sir_model import compute_R0
from src.config import PAPER_TARGET, N_TOTAL_POPULATION, TABLES_DIR, RESULTS_DIR


def run_main_estimation():
    print("=" * 60)
    print("AI-SIR 主参数估计 — 对应论文 Section 4.2.2")
    print("=" * 60)
    
    videos = load_videos()
    print(f"\n[1] 构造 I(t) 时间序列 (N_eff={N_TOTAL_POPULATION})")
    I_obs = build_It_from_videos(videos)
    print(f"    I(t) 长度: {len(I_obs)}")
    print(f"    I(t) 峰值: {I_obs.max():.0f}, 时点: 第 {I_obs.argmax()+1} 天")
    
    alpha = PAPER_TARGET["alpha_naive"]
    delta = PAPER_TARGET["delta_full"]
    print(f"\n[2] 固定外部估计值")
    print(f"    α = {alpha} (Section 4.1)")
    print(f"    δ = {delta} (Section 4.1)")
    
    print(f"\n[3] NLS 拟合 β、γ (Trust-Region-Reflective)")
    fit = fit_ai_sir(
        I_obs, alpha, delta,
        N=N_TOTAL_POPULATION,
        beta0=PAPER_TARGET["beta_naive"],
        gamma0=PAPER_TARGET["gamma_naive"],
        S0=N_TOTAL_POPULATION - 500, I0=500.0, R0_init=0.0,
    )
    
    print(f"\n[4] 拟合结果 — Table 5")
    table5 = pd.DataFrame([
        ("β", round(fit["beta"], 3),
         f"[{fit['beta_ci'][0]:.3f}, {fit['beta_ci'][1]:.3f}]",
         round(fit["beta_se"], 3), "Baseline transmission rate"),
        ("γ", round(fit["gamma"], 3),
         f"[{fit['gamma_ci'][0]:.3f}, {fit['gamma_ci'][1]:.3f}]",
         round(fit["gamma_se"], 3), "Recovery rate"),
        ("α", alpha, "—", "—", "AI amplification (externally calculated)"),
        ("δ", delta, "[0.583, 0.653]", 0.018, "Cultural discount factor"),
        ("R₀", round(fit["R0"], 3),
         f"[{fit['R0_ci'][0]:.3f}, {fit['R0_ci'][1]:.3f}]", "—",
         "Basic reproduction number"),
    ], columns=["Parameter", "Estimated_Value", "95_CI",
                "Standard_Error", "Physical_Meaning"])
    print(table5.to_string(index=False))
    table5.to_csv(TABLES_DIR / "table5_main_parameters.csv",
                  index=False, encoding="utf-8-sig")
    
    print(f"\n[5] 拟合诊断 (Section 4.2.2)")
    dw = durbin_watson(fit["residuals"])
    Q20, p20 = ljung_box(fit["residuals"], lags=20)
    print(f"    R²:                  {fit['R2']:.3f} (论文 {PAPER_TARGET['R2_full']})")
    print(f"    RMSE:                {fit['RMSE']:.0f} (论文 {PAPER_TARGET['RMSE_full']})")
    print(f"    Durbin-Watson:        {dw:.3f} (论文 {PAPER_TARGET['DW']})")
    print(f"    Ljung-Box Q(20):     {Q20:.2f}, p={p20:.3f} "
          f"(论文 22.7, p=0.317)")
    print(f"    条件数:               {fit['condition_number']:.2e} "
          f"(论文 3.42×10³)")
    print(f"    迭代次数:             {fit['n_iter']}")
    print(f"    收敛:                 {fit['converged']}")
    
    # 保存结果
    summary = pd.DataFrame([
        ("beta_estimated", fit["beta"]),
        ("gamma_estimated", fit["gamma"]),
        ("alpha_input", alpha),
        ("delta_input", delta),
        ("R0_estimated", fit["R0"]),
        ("R2", fit["R2"]),
        ("RMSE", fit["RMSE"]),
        ("durbin_watson", dw),
        ("ljung_box_Q20", Q20),
        ("ljung_box_p20", p20),
        ("condition_number", fit["condition_number"]),
        ("beta_se", fit["beta_se"]),
        ("gamma_se", fit["gamma_se"]),
        ("R0_se", fit["R0_se"]),
        ("beta_ci_low", fit["beta_ci"][0]),
        ("beta_ci_high", fit["beta_ci"][1]),
        ("gamma_ci_low", fit["gamma_ci"][0]),
        ("gamma_ci_high", fit["gamma_ci"][1]),
        ("R0_ci_low", fit["R0_ci"][0]),
        ("R0_ci_high", fit["R0_ci"][1]),
        ("n_iterations", fit["n_iter"]),
        ("converged", fit["converged"]),
    ], columns=["Metric", "Value"])
    summary.to_csv(RESULTS_DIR / "main_estimation_results.csv",
                   index=False, encoding="utf-8-sig")
    
    # 同时保存 I_obs 与 I_pred 序列以供后续使用
    pd.DataFrame({
        "day": range(len(I_obs)),
        "I_obs": I_obs,
        "I_pred": fit["I_pred"],
        "residual": fit["residuals"],
    }).to_csv(RESULTS_DIR / "It_observed_vs_predicted.csv",
              index=False, encoding="utf-8-sig")
    
    return fit


if __name__ == "__main__":
    run_main_estimation()
    print("\n✓ Section 4.2.2 (Main Estimation) 完成")
