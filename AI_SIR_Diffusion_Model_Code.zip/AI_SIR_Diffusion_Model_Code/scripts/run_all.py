#!/usr/bin/env python3
"""
主编排脚本 — 端到端运行整个 AI-SIR 跨文化传播实证研究

执行顺序对应论文 Section 4 的分析流程:

  Section 4.1     — 描述性统计与预处理
  Section 4.2.1   — 人工验证 + PSM
  Section 4.2.2   — AI-SIR 主参数估计
  Section 4.3.1   — 按内容类型 + 区域分析
  Section 4.3.2   — 情感极性调节效应
  Section 4.3.3   — 参数灵敏度分析
  Section 4.4     — 七维稳健性检验
  Figures 3-8     — 所有论文图表
"""
import sys
import time
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src.preprocessing import run_preprocessing
from src.ai_detection import run_ai_detection_validation
from src.psm import run_psm
from src.content_analysis import run_content_analysis
from src.regional_analysis import run_regional_analysis
from src.sentiment_analysis import run_sentiment_analysis
from src.sensitivity_analysis import run_sensitivity
from src.robustness_checks import run_robustness
from src.visualization import run_all_figures


def banner(text):
    print("\n" + "█" * 70)
    print(f"█  {text}")
    print("█" * 70)


def main():
    t0 = time.time()
    
    banner("Step 1/10 — Section 4.1: 描述性统计与数据预处理")
    run_preprocessing()
    
    banner("Step 2/10 — Section 4.2.1: 人工验证 (Manual Validation)")
    run_ai_detection_validation()
    
    banner("Step 3/10 — Section 3.5 + 4.2.1: 倾向得分匹配 (PSM)")
    run_psm()
    
    banner("Step 4/10 — Section 4.2.2: AI-SIR 主参数估计 (NLS)")
    # 内嵌运行主估计 (与 scripts/04 内容相同)
    import importlib.util
    script04 = Path(__file__).resolve().parent / "04_main_estimation.py"
    spec = importlib.util.spec_from_file_location("script04", script04)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    mod.run_main_estimation()
    
    banner("Step 5/10 — Section 4.3.1: 按内容类型分析 (Table 6)")
    run_content_analysis()
    
    banner("Step 6/10 — Section 4.3.1: 区域文化折扣 (Table 7)")
    run_regional_analysis()
    
    banner("Step 7/10 — Section 4.3.2: 情感极性调节 (Table 8)")
    run_sentiment_analysis()
    
    banner("Step 8/10 — Section 4.3.3: 参数灵敏度分析 (Figure 7)")
    run_sensitivity()
    
    banner("Step 9/10 — Section 4.4: 稳健性检验 (Tables 9-12)")
    run_robustness()
    
    banner("Step 10/10 — 论文 Figures 3-8 可视化")
    run_all_figures()
    
    elapsed = time.time() - t0
    print("\n" + "█" * 70)
    print(f"█  全部完成 ✓  总耗时 {elapsed:.1f} 秒")
    print("█" * 70)
    print("\n请查看:")
    print("  outputs/tables/   — 所有 CSV 表格")
    print("  outputs/figures/  — 所有 PNG 图表")
    print("  outputs/reports/  — 综合结果汇总")


if __name__ == "__main__":
    main()
