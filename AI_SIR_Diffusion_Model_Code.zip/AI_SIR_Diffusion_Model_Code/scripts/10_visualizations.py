#!/usr/bin/env python3
"""脚本 10: 生成所有图表 (论文 Figures 3-8)"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src.visualization import run_all_figures

if __name__ == "__main__":
    run_all_figures()
    print("\n✓ 所有可视化图表 (Figures 3-8) 完成")
