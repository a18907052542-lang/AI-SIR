#!/usr/bin/env python3
"""
脚本 02: 人工验证 (论文 Section 4.2.1)

  - GPTZero 自动检测全样本应用
  - 300 样本人工分层标注 (双编码员 + 仲裁)
  - Cohen's κ、Accuracy、Precision、Recall、F1
  - 双检测器 (GPTZero vs Originality) 一致性
  - Bias-corrected AI 比例
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src.ai_detection import run_ai_detection_validation


if __name__ == "__main__":
    run_ai_detection_validation()
    print("\n✓ Section 4.2.1 (Manual Validation) 完成")
