#!/usr/bin/env python3
"""脚本 06: 区域文化折扣分析 (论文 Section 4.3.1 + Table 7)"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src.regional_analysis import run_regional_analysis

if __name__ == "__main__":
    run_regional_analysis()
    print("\n✓ Section 4.3.1 (Regional Analysis) 完成")
