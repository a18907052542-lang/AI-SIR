#!/usr/bin/env python3
"""
脚本 01: 描述性统计 (论文 Section 4.1)

  - 完整性验证
  - 47,218 → 18,326 预处理日志
  - Table 3: 描述统计
  - Table 4: AI vs Human 对比
  - α (naive) 计算
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src.preprocessing import run_preprocessing


if __name__ == "__main__":
    run_preprocessing()
    print("\n✓ Section 4.1 完成")
