#!/usr/bin/env python3
"""脚本 08: 参数灵敏度分析 (论文 Section 4.3.3 + Figure 7)"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src.sensitivity_analysis import run_sensitivity

if __name__ == "__main__":
    run_sensitivity()
    print("\n✓ Section 4.3.3 (Sensitivity Analysis) 完成")
