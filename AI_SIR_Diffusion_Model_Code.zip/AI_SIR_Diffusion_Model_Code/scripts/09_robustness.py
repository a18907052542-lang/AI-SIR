#!/usr/bin/env python3
"""脚本 09: 稳健性检验 (论文 Section 4.4 + Tables 9-12)"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src.robustness_checks import run_robustness

if __name__ == "__main__":
    run_robustness()
    print("\n✓ Section 4.4 (Robustness Checks) 完成")
