#!/usr/bin/env python3
"""脚本 07: 情感极性调节效应 (论文 Section 4.3.2 + Table 8)"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src.sentiment_analysis import run_sentiment_analysis

if __name__ == "__main__":
    run_sentiment_analysis()
    print("\n✓ Section 4.3.2 (Sentiment Analysis) 完成")
