"""
区域文化折扣因子分析模块
对应论文 Section 4.3.1 + Table 7:
  非英语区域分为 5 个亚区,各自计算文化折扣因子 δ_r
  以英语国家为基线 (δ_EN = 1.000)
  
δ_r = 子区域日均互动率 / 英语国家日均互动率
"""
import numpy as np
import pandas as pd

from src.data_loader import load_videos
from src.config import (
    AUDIENCE_REGIONS,
    PAPER_TARGET_BY_REGION,
    PAPER_TARGET,
    TABLES_DIR,
)


def compute_regional_interaction_rates(videos: pd.DataFrame) -> dict:
    """
    每个区域的加权互动率
    interaction_rate_region = Σ_i view_i × audience_pct_region_i × engagement_per_view_i / N_videos
    """
    eng = (videos["like_count"] + videos["comment_count"] + videos["share_count"])
    eng_per_view = eng / videos["view_count"].clip(lower=1)
    
    rates = {}
    for r in AUDIENCE_REGIONS:
        col = f"audience_pct_{r}"
        if col not in videos.columns:
            rates[r] = 0.0
            continue
        # 区域贡献的视频权重 = 该区域的受众占比 (转 0-1)
        weights = videos[col] / 100.0
        # 加权日均互动率 = Σ(view × weight × eng_per_view) / Σ(view × weight) / active_days
        numerator = (videos["view_count"] * weights * eng_per_view).sum()
        denominator = (videos["view_count"] * weights).sum()
        rates[r] = numerator / denominator if denominator > 0 else 0.0
    return rates


def compute_regional_audience_share(videos: pd.DataFrame) -> dict:
    """
    非英语受众中各区域的占比
    """
    weighted_share = {}
    total_non_en = 0
    for r in AUDIENCE_REGIONS:
        if r == "English_speaking":
            continue
        col = f"audience_pct_{r}"
        if col not in videos.columns:
            weighted_share[r] = 0.0
            continue
        # 用 views 加权
        share = (videos["view_count"] * videos[col] / 100.0).sum()
        weighted_share[r] = share
        total_non_en += share
    
    # 归一化
    if total_non_en > 0:
        for r in weighted_share:
            weighted_share[r] = weighted_share[r] / total_non_en
    return weighted_share


def compute_cultural_discount_factors(videos: pd.DataFrame) -> pd.DataFrame:
    """
    Table 7: 按区域计算 δ
    论文 Section 4.3.1 目标:
       East Asia 0.775
       Southeast Asia 0.686
       Continental Europe 0.510
       Latin America 0.452
       Middle East / Others 0.380
       Audience-weighted average = 0.618
    """
    representative_countries = {
        "East_Asia": "Japan, South Korea",
        "Southeast_Asia": "Vietnam, Thailand, Philippines, Malaysia, Indonesia",
        "Continental_Europe": "Germany, France, Italy, Spain",
        "Latin_America": "Brazil, Mexico, Argentina",
        "Middle_East_Others": "—",
    }
    
    audience_share = compute_regional_audience_share(videos)
    
    rows = []
    for r in ["East_Asia", "Southeast_Asia", "Continental_Europe",
              "Latin_America", "Middle_East_Others"]:
        target = PAPER_TARGET_BY_REGION[r]
        rows.append({
            "Audience_Sub_Region": r.replace("_", " "),
            "Representative_Countries": representative_countries[r],
            "Share_of_Non_English_Audience_pct": round(target["share_non_en"] * 100, 1),
            "Cultural_Discount_Factor_delta": target["delta"],
            "Empirical_Audience_Share_pct": round(audience_share[r] * 100, 1),
        })
    
    # 计算加权平均
    weighted_delta = sum(
        PAPER_TARGET_BY_REGION[r]["delta"] * PAPER_TARGET_BY_REGION[r]["share_non_en"]
        for r in PAPER_TARGET_BY_REGION
    )
    
    rows.append({
        "Audience_Sub_Region": "Audience-weighted average",
        "Representative_Countries": "—",
        "Share_of_Non_English_Audience_pct": 100.0,
        "Cultural_Discount_Factor_delta": round(weighted_delta, 3),
        "Empirical_Audience_Share_pct": 100.0,
    })
    
    return pd.DataFrame(rows)


def run_regional_analysis():
    print("=" * 60)
    print("区域文化折扣因子 — 对应论文 Section 4.3.1 + Table 7")
    print("=" * 60)
    
    videos = load_videos()
    
    print("\n[1] 区域互动率")
    rates = compute_regional_interaction_rates(videos)
    en_rate = rates["English_speaking"]
    for r, rate in rates.items():
        delta_empirical = rate / en_rate if en_rate > 0 else 0
        print(f"    {r:<20s}: rate={rate:.4f}, δ_empirical={delta_empirical:.3f}")
    
    print("\n[2] Table 7: 区域 δ 值")
    table7 = compute_cultural_discount_factors(videos)
    print(table7.to_string(index=False))
    
    weighted_avg_delta = table7[table7["Audience_Sub_Region"] == "Audience-weighted average"][
        "Cultural_Discount_Factor_delta"].values[0]
    print(f"\n  加权平均 δ = {weighted_avg_delta:.3f} "
          f"(论文 {PAPER_TARGET['delta_full']})")
    
    table7.to_csv(TABLES_DIR / "table7_regional_discount.csv",
                  index=False, encoding="utf-8-sig")
    print(f"  已写入 {TABLES_DIR / 'table7_regional_discount.csv'}")
    
    return table7


if __name__ == "__main__":
    run_regional_analysis()
