"""
AI 内容检测与人工验证模块
对应论文 Section 3.4 + 4.2.1:
  - GPTZero 自动检测 (阈值 0.70)
  - Originality.ai 双检测验证
  - 300 样本人工分层标注 (150 AI-flagged + 150 Human-flagged)
  - 两位双语编码员 + 第三位资深仲裁
  - Cohen's κ、Accuracy、Precision、Recall、F1
  - Bias-corrected AI 比例投影到全样本
"""
import numpy as np
import pandas as pd
from sklearn.metrics import (
    cohen_kappa_score,
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    confusion_matrix,
)

from src.data_loader import load_manual_annotations, load_videos, load_ai_features
from src.config import (
    TABLES_DIR, RESULTS_DIR,
    AI_DETECTION_THRESHOLD,
    PAPER_TARGET,
)


def apply_ai_detection_threshold(scores: np.ndarray, threshold: float = 0.70) -> np.ndarray:
    """
    GPTZero 阈值化:得分 >= threshold → AI 标记
    对应论文 Section 3.4: "labeling content with a detection probability
    exceeding 70% as AI-assisted generation"
    """
    return (scores >= threshold).astype(int)


def compute_cohen_kappa(coder_a: np.ndarray, coder_b: np.ndarray) -> float:
    """Cohen's κ 二编码员一致性"""
    return cohen_kappa_score(coder_a, coder_b)


def compute_classification_metrics(y_true: np.ndarray,
                                    y_pred: np.ndarray) -> dict:
    """
    计算自动检测对人工金标准的分类指标
    AI = 1 为 positive 类
    """
    return {
        "accuracy":  accuracy_score(y_true, y_pred),
        "precision": precision_score(y_true, y_pred, zero_division=0),
        "recall":    recall_score(y_true, y_pred, zero_division=0),
        "f1":        f1_score(y_true, y_pred, zero_division=0),
    }


def bias_corrected_ai_proportion(naive_prop: float,
                                  precision: float,
                                  recall: float) -> float:
    """
    根据 Precision 和 Recall 校正 AI 比例
    论文 Section 4.2.1: naive 36.6% → bias-corrected 38.9%
    
    校正逻辑 (基于混淆矩阵):
        naive_prop ≈ TP + FP / N
        TP / (TP+FP) = precision → TP = precision * (naive_prop * N)
        TP / (TP+FN) = recall → TP+FN = TP/recall
        true_prop = (TP+FN) / N = (precision/recall) * naive_prop
    """
    return naive_prop * (precision / recall)


def compute_inter_detector_agreement(ai_features: pd.DataFrame) -> dict:
    """
    GPTZero vs Originality.ai 一致性 (论文 4.2.1: κ ≈ 0.74)
    """
    gz_binary = (ai_features["gptzero_ai_probability"] >= 0.5).astype(int)
    or_binary = (ai_features["originality_ai_probability"] >= 0.5).astype(int)
    kappa = cohen_kappa_score(gz_binary, or_binary)
    agreement_rate = (gz_binary == or_binary).mean()
    return {"inter_detector_kappa": kappa,
            "inter_detector_agreement": agreement_rate}


def manual_validation_summary(manual_df: pd.DataFrame) -> dict:
    """
    300 样本人工验证结果汇总
    论文 Section 4.2.1 目标:
        κ=0.81, Acc=0.830, Prec=0.860, Rec=0.811, F1=0.835
    """
    coder_a = manual_df["coder_A_label"].values
    coder_b = manual_df["coder_B_label"].values
    consensus = manual_df["consensus_or_arbitration"].values
    automated = manual_df["automated_label"].values
    
    kappa = compute_cohen_kappa(coder_a, coder_b)
    metrics_vs_consensus = compute_classification_metrics(consensus, automated)
    cm = confusion_matrix(consensus, automated)
    
    return {
        "n_samples": len(manual_df),
        "n_ai_flagged_subset": int((manual_df["subset_stratum"] == "AI-flagged").sum()),
        "n_human_flagged_subset": int((manual_df["subset_stratum"] == "Human-flagged").sum()),
        "cohen_kappa_coder_A_vs_B": float(kappa),
        "automated_vs_consensus_accuracy": float(metrics_vs_consensus["accuracy"]),
        "automated_vs_consensus_precision": float(metrics_vs_consensus["precision"]),
        "automated_vs_consensus_recall": float(metrics_vs_consensus["recall"]),
        "automated_vs_consensus_f1": float(metrics_vs_consensus["f1"]),
        "confusion_matrix": cm.tolist(),
        "coder_A_B_agreement_rate": float((coder_a == coder_b).mean()),
    }


def run_ai_detection_validation():
    print("=" * 60)
    print("AI 内容检测与人工验证 — 对应论文 Section 4.2.1")
    print("=" * 60)
    
    videos = load_videos()
    manual = load_manual_annotations()
    ai_features = load_ai_features()
    
    # [1] 全样本 GPTZero 自动检测
    naive_ai_count = int(videos["ai_assisted_flag"].sum())
    naive_ai_prop = naive_ai_count / len(videos)
    print(f"\n[1] 全样本自动检测 (GPTZero, 阈值 0.70):")
    print(f"    AI 标记数:   {naive_ai_count} / {len(videos)} = {naive_ai_prop*100:.1f}%")
    print(f"    论文目标:     6,714 / 18,326 = 36.6%")
    
    # [2] 双检测一致性 (GPTZero vs Originality)
    inter = compute_inter_detector_agreement(ai_features)
    print(f"\n[2] 双检测一致性 (Section 4.2.1):")
    print(f"    GPTZero ↔ Originality 一致率: {inter['inter_detector_agreement']*100:.1f}%")
    print(f"    Cohen's κ: {inter['inter_detector_kappa']:.3f}")
    
    # [3] 300 样本人工验证
    val = manual_validation_summary(manual)
    print(f"\n[3] 300 样本人工验证 (Section 4.2.1):")
    print(f"    样本: {val['n_samples']} = {val['n_ai_flagged_subset']} AI-flagged "
          f"+ {val['n_human_flagged_subset']} Human-flagged")
    print(f"    Cohen's κ (A vs B): {val['cohen_kappa_coder_A_vs_B']:.3f} "
          f"(论文 {PAPER_TARGET['kappa']})")
    print(f"    Accuracy:  {val['automated_vs_consensus_accuracy']:.3f} "
          f"(论文 {PAPER_TARGET['accuracy']})")
    print(f"    Precision: {val['automated_vs_consensus_precision']:.3f} "
          f"(论文 {PAPER_TARGET['precision']})")
    print(f"    Recall:    {val['automated_vs_consensus_recall']:.3f} "
          f"(论文 {PAPER_TARGET['recall']})")
    print(f"    F1:        {val['automated_vs_consensus_f1']:.3f} "
          f"(论文 {PAPER_TARGET['f1']})")
    
    # [4] Bias-corrected AI 比例
    bc_prop = bias_corrected_ai_proportion(
        naive_ai_prop,
        val["automated_vs_consensus_precision"],
        val["automated_vs_consensus_recall"]
    )
    print(f"\n[4] Bias-corrected AI 比例:")
    print(f"    Naive:      {naive_ai_prop*100:.1f}%")
    print(f"    Corrected:  {bc_prop*100:.1f}%")
    print(f"    论文目标:    36.6% → 38.9%")
    
    # 保存结果
    results = pd.DataFrame([
        ("naive_ai_proportion", naive_ai_prop),
        ("bias_corrected_ai_proportion", bc_prop),
        ("cohen_kappa_AB", val["cohen_kappa_coder_A_vs_B"]),
        ("accuracy",  val["automated_vs_consensus_accuracy"]),
        ("precision", val["automated_vs_consensus_precision"]),
        ("recall",    val["automated_vs_consensus_recall"]),
        ("f1",        val["automated_vs_consensus_f1"]),
        ("inter_detector_kappa", inter["inter_detector_kappa"]),
        ("inter_detector_agreement", inter["inter_detector_agreement"]),
    ], columns=["Metric", "Value"])
    
    results.to_csv(TABLES_DIR / "table_manual_validation.csv",
                   index=False, encoding="utf-8-sig")
    
    # 保存详细的 manual sample 验证表
    detailed = pd.DataFrame([{
        "Sample_Strata": "AI-flagged (n=150) + Human-flagged (n=150)",
        "Coder_A_B_agreement_rate": val["coder_A_B_agreement_rate"],
        "Cohen_kappa": val["cohen_kappa_coder_A_vs_B"],
        "Confusion_matrix_TN_FP_FN_TP": str(val["confusion_matrix"]),
        "Accuracy": val["automated_vs_consensus_accuracy"],
        "Precision": val["automated_vs_consensus_precision"],
        "Recall": val["automated_vs_consensus_recall"],
        "F1": val["automated_vs_consensus_f1"],
    }])
    detailed.to_csv(TABLES_DIR / "manual_validation_detailed.csv",
                    index=False, encoding="utf-8-sig")
    
    return {
        "naive_ai_proportion": naive_ai_prop,
        "bias_corrected_ai_proportion": bc_prop,
        **val,
        **inter,
    }


if __name__ == "__main__":
    run_ai_detection_validation()
