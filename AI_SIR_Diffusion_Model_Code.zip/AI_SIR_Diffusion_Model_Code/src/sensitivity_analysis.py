"""
参数灵敏度分析模块
对应论文 Section 4.3.3 + Figure 7:
  α, δ, β, γ 各自在 ±20% 区间内变化, 其他参数固定
  记录 R₀, peak timing, peak magnitude 的响应

论文报告:
  γ -20% → R₀ +25.0%, γ +20% → R₀ -16.7%
  峰值响应: γ -20% → peak magnitude +28.6% (所有参数中最大)
"""
import numpy as np
import pandas as pd

from src.sir_model import solve_ai_sir_rk4, compute_R0, find_peak
from src.config import (
    PAPER_TARGET, N_TOTAL_POPULATION, OBSERVATION_DAYS,
    TABLES_DIR, RESULTS_DIR,
)


def run_sensitivity_grid(alpha_base, delta_base, beta_base, gamma_base,
                          variations=(-0.20, -0.10, 0.0, 0.10, 0.20),
                          N=N_TOTAL_POPULATION,
                          I0=500, T=OBSERVATION_DAYS) -> pd.DataFrame:
    """
    每个参数 (α, δ, β, γ) 单独变化, 其他保持基线
    """
    rows = []
    
    # 基线
    R0_base = compute_R0(alpha_base, delta_base, beta_base, gamma_base)
    _, _, I_base, _ = solve_ai_sir_rk4(
        alpha_base, delta_base, beta_base, gamma_base,
        N=N, S0=N-I0, I0=I0, R0_init=0, T=T
    )
    peak_idx_base, peak_val_base = find_peak(I_base)
    
    for param in ["alpha", "delta", "beta", "gamma"]:
        for var in variations:
            a, d, b, g = alpha_base, delta_base, beta_base, gamma_base
            if   param == "alpha": a = alpha_base * (1 + var)
            elif param == "delta": d = delta_base * (1 + var)
            elif param == "beta":  b = beta_base * (1 + var)
            elif param == "gamma": g = gamma_base * (1 + var)
            
            R0 = compute_R0(a, d, b, g)
            _, _, I, _ = solve_ai_sir_rk4(
                a, d, b, g, N=N, S0=N-I0, I0=I0, R0_init=0, T=T
            )
            peak_idx, peak_val = find_peak(I)
            
            rows.append({
                "param": param,
                "variation_pct": var * 100,
                "R0": R0,
                "R0_change_pct": (R0 - R0_base) / R0_base * 100,
                "peak_day": peak_idx,
                "peak_day_change": peak_idx - peak_idx_base,
                "peak_magnitude": peak_val,
                "peak_change_pct": (peak_val - peak_val_base) / peak_val_base * 100,
            })
    
    return pd.DataFrame(rows)


def compute_elasticity_coefficients(sens_df: pd.DataFrame) -> pd.DataFrame:
    """
    弹性系数:
        ε_param,R0 = (ΔR₀/R₀) / (Δparam/param)
    线性弹性应为 ±1 (α, δ, β),γ 因在分母为 -1
    """
    rows = []
    for param in ["alpha", "delta", "beta", "gamma"]:
        # 用 ±20% 两端的 R₀ 变化计算
        plus = sens_df[(sens_df["param"] == param) & (sens_df["variation_pct"] == 20)]
        minus = sens_df[(sens_df["param"] == param) & (sens_df["variation_pct"] == -20)]
        if not plus.empty and not minus.empty:
            elasticity = (plus["R0_change_pct"].values[0] -
                         minus["R0_change_pct"].values[0]) / 40
            rows.append({
                "param": param,
                "R0_change_pct_plus20": plus["R0_change_pct"].values[0],
                "R0_change_pct_minus20": minus["R0_change_pct"].values[0],
                "elasticity_coefficient_R0": round(elasticity, 3),
                "peak_change_pct_minus20": minus["peak_change_pct"].values[0],
            })
    return pd.DataFrame(rows)


def run_sensitivity():
    print("=" * 60)
    print("参数灵敏度分析 — 对应论文 Section 4.3.3 + Figure 7")
    print("=" * 60)
    
    sens_df = run_sensitivity_grid(
        alpha_base=PAPER_TARGET["alpha_naive"],
        delta_base=PAPER_TARGET["delta_full"],
        beta_base=PAPER_TARGET["beta_naive"],
        gamma_base=PAPER_TARGET["gamma_naive"],
    )
    
    print("\n[1] 灵敏度网格 (各参数 ±20% 单变量扰动)")
    print(sens_df.to_string(index=False))
    
    print("\n[2] 弹性系数")
    elast = compute_elasticity_coefficients(sens_df)
    print(elast.to_string(index=False))
    
    # 论文核心发现验证
    gamma_minus = sens_df[(sens_df["param"] == "gamma") & (sens_df["variation_pct"] == -20)]
    if not gamma_minus.empty:
        peak_change = gamma_minus["peak_change_pct"].values[0]
        R0_change = gamma_minus["R0_change_pct"].values[0]
        print(f"\n[3] 论文核心发现验证:")
        print(f"    γ -20% → R₀ 变化 {R0_change:+.1f}% (论文 +25.0%)")
        print(f"    γ -20% → peak magnitude 变化 {peak_change:+.1f}% (论文 +28.6%)")
    
    sens_df.to_csv(TABLES_DIR / "sensitivity_grid.csv",
                   index=False, encoding="utf-8-sig")
    elast.to_csv(TABLES_DIR / "sensitivity_elasticity.csv",
                 index=False, encoding="utf-8-sig")
    return sens_df, elast


if __name__ == "__main__":
    run_sensitivity()
