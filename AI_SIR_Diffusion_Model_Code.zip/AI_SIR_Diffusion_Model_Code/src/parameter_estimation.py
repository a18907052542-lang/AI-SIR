"""
非线性最小二乘 (NLS) 参数估计
对应论文 Section 3.6 公式 (4)

目标函数:
    min_{β,γ} Σ_t [I_obs(t) - I_model(t; β, γ, α, δ)]²

优化算法:Trust-Region-Reflective (scipy.optimize.least_squares, method='trf')
约束:β > 0, γ > 0
"""
import numpy as np
from scipy.optimize import least_squares
from scipy.stats import chi2

from src.sir_model import solve_ai_sir_rk4, compute_R0
from src.config import (
    N_TOTAL_POPULATION,
    NLS_METHOD,
    NLS_MAX_NFEV,
    NLS_BOUNDS,
)


def residuals(params, I_obs, alpha, delta, N, S0, I0, R0_init, T):
    """
    残差函数: I_obs(t) - I_model(t)
    """
    beta, gamma = params
    if beta <= 0 or gamma <= 0:
        return np.ones_like(I_obs) * 1e10
    
    _, _, I_model, _ = solve_ai_sir_rk4(
        alpha, delta, beta, gamma, N, S0, I0, R0_init, T
    )
    
    # I_model 长度比 I_obs 多 1 (含初始时刻)
    return I_obs - I_model[:len(I_obs)]


def fit_ai_sir(I_obs, alpha, delta,
               N=100000,
               beta0=0.12, gamma0=0.06,
               S0=None, I0=None, R0_init=0):
    """
    用 NLS 拟合 AI-SIR 模型,得到 β 和 γ 的最优估计
    
    参数
    ----
    I_obs : ndarray (T,) 观测的活跃传播者数序列
    alpha : 外部估计的 AI 放大系数 (固定)
    delta : 外部估计的文化折扣因子 (固定)
    N, S0, I0, R0_init : 总人口与初始条件
    beta0, gamma0 : 初值
    
    返回
    ----
    dict, 含 beta, gamma, R0, R2, RMSE, std_err, confidence_intervals, cost
    """
    T = len(I_obs) - 1   # 时间步数
    
    # IC: 论文 Section 3.6 用估计起点的近似值;为保持数值稳定,
    # 使用 I_obs 前 7 日的均值作为 I0 估计,而非首日单点(易受噪声影响)
    if I0 is None:
        I0 = max(float(np.mean(I_obs[:7])), 1.0)
    if S0 is None:
        S0 = N - I0 - R0_init
    
    # 优化
    result = least_squares(
        residuals,
        x0=[beta0, gamma0],
        args=(I_obs, alpha, delta, N, S0, I0, R0_init, T),
        bounds=NLS_BOUNDS,
        method=NLS_METHOD,
        max_nfev=NLS_MAX_NFEV,
    )
    
    beta_hat, gamma_hat = result.x
    
    # 拟合优度
    _, _, I_model, _ = solve_ai_sir_rk4(
        alpha, delta, beta_hat, gamma_hat, N, S0, I0, R0_init, T
    )
    I_pred = I_model[:len(I_obs)]
    residuals_arr = I_obs - I_pred
    SS_res = np.sum(residuals_arr ** 2)
    SS_tot = np.sum((I_obs - np.mean(I_obs)) ** 2)
    R2 = 1 - SS_res / SS_tot
    RMSE = np.sqrt(np.mean(residuals_arr ** 2))
    
    # 标准误 (从 Jacobian 估计)
    J = result.jac
    n_obs = len(I_obs)
    p = 2  # 参数数量
    sigma2 = SS_res / (n_obs - p)
    try:
        cov = sigma2 * np.linalg.inv(J.T @ J)
        std_err = np.sqrt(np.diag(cov))
        beta_se, gamma_se = std_err
    except np.linalg.LinAlgError:
        beta_se = gamma_se = np.nan
    
    # 95% CI (使用 t 分布 ≈ 1.96)
    ci_beta = (beta_hat - 1.96 * beta_se, beta_hat + 1.96 * beta_se)
    ci_gamma = (gamma_hat - 1.96 * gamma_se, gamma_hat + 1.96 * gamma_se)
    
    # R0 与其 95% CI (delta 方法 + α, δ 已知)
    R0_hat = compute_R0(alpha, delta, beta_hat, gamma_hat)
    # delta method: var(R0) ≈ (∂R0/∂β)²·var(β) + (∂R0/∂γ)²·var(γ)
    dR0_dbeta = alpha * delta / gamma_hat
    dR0_dgamma = -alpha * delta * beta_hat / (gamma_hat ** 2)
    R0_var = (dR0_dbeta ** 2) * (beta_se ** 2) + (dR0_dgamma ** 2) * (gamma_se ** 2)
    R0_se = np.sqrt(R0_var) if R0_var > 0 else np.nan
    ci_R0 = (R0_hat - 1.96 * R0_se, R0_hat + 1.96 * R0_se)
    
    # 条件数 (Hessian)
    try:
        H = J.T @ J
        cond_number = np.linalg.cond(H)
    except np.linalg.LinAlgError:
        cond_number = np.nan
    
    return {
        "beta": beta_hat,
        "gamma": gamma_hat,
        "alpha": alpha,
        "delta": delta,
        "R0": R0_hat,
        "beta_se": beta_se,
        "gamma_se": gamma_se,
        "R0_se": R0_se,
        "beta_ci": ci_beta,
        "gamma_ci": ci_gamma,
        "R0_ci": ci_R0,
        "R2": R2,
        "RMSE": RMSE,
        "n_obs": n_obs,
        "cost": result.cost,
        "n_iter": result.nfev,
        "condition_number": cond_number,
        "I_pred": I_pred,
        "residuals": residuals_arr,
        "converged": result.success,
    }


def durbin_watson(residuals):
    """Durbin-Watson 统计量,检验残差一阶自相关"""
    diff = np.diff(residuals)
    return float(np.sum(diff ** 2) / np.sum(residuals ** 2))


def ljung_box(residuals, lags=20):
    """
    Ljung-Box Q 检验
    H0: 残差无自相关 (前 lags 阶)
    """
    n = len(residuals)
    acf = []
    mean = np.mean(residuals)
    var = np.sum((residuals - mean) ** 2)
    for k in range(1, lags + 1):
        cov_k = np.sum((residuals[:-k] - mean) * (residuals[k:] - mean))
        acf.append(cov_k / var)
    acf = np.array(acf)
    Q = n * (n + 2) * np.sum(acf ** 2 / (n - np.arange(1, lags + 1)))
    p_val = 1 - chi2.cdf(Q, df=lags)
    return float(Q), float(p_val)


def time_decay_loss(params, I_obs, alpha, delta, N, S0, I0, R0_init, T):
    """加时间衰减项 e^{-λt} (论文 Section 4.4)"""
    beta, gamma, lam = params
    if beta <= 0 or gamma <= 0 or lam < 0:
        return np.ones_like(I_obs) * 1e10
    _, _, I_model, _ = solve_ai_sir_rk4(alpha, delta, beta, gamma, N, S0, I0, R0_init, T)
    decay = np.exp(-lam * np.arange(len(I_obs)))
    return (I_obs - I_model[:len(I_obs)]) * decay


def fit_with_time_decay(I_obs, alpha, delta,
                         N=100000,
                         beta0=0.12, gamma0=0.06, lam0=0.003,
                         S0=None, I0=None, R0_init=0):
    """带时间衰减函数 e^{-λt} 的拟合 (论文 Section 4.4)"""
    T = len(I_obs) - 1
    if I0 is None:
        I0 = max(I_obs[0], 1)
    if S0 is None:
        S0 = N - I0 - R0_init
    
    result = least_squares(
        time_decay_loss,
        x0=[beta0, gamma0, lam0],
        args=(I_obs, alpha, delta, N, S0, I0, R0_init, T),
        bounds=([1e-4, 1e-4, 0], [2.0, 1.0, 0.5]),
        method="trf",
        max_nfev=NLS_MAX_NFEV,
    )
    beta_hat, gamma_hat, lam_hat = result.x
    _, _, I_model, _ = solve_ai_sir_rk4(alpha, delta, beta_hat, gamma_hat, N, S0, I0, R0_init, T)
    I_pred = I_model[:len(I_obs)]
    SS_res = np.sum((I_obs - I_pred) ** 2)
    SS_tot = np.sum((I_obs - np.mean(I_obs)) ** 2)
    R2 = 1 - SS_res / SS_tot
    return {
        "beta": beta_hat, "gamma": gamma_hat, "lambda": lam_hat,
        "R0": compute_R0(alpha, delta, beta_hat, gamma_hat),
        "R2": R2, "half_life_days": np.log(2) / lam_hat if lam_hat > 0 else np.inf,
    }


if __name__ == "__main__":
    from src.data_loader import load_all_data, build_It_from_videos
    from src.config import PAPER_TARGET
    
    print("=== 拟合自检 ===")
    data = load_all_data()
    I_t = build_It_from_videos(data["videos"])
    print(f"I(t) 长度={len(I_t)}, 范围=[{I_t.min():.0f}, {I_t.max():.0f}]")
    
    fit_result = fit_ai_sir(
        I_t,
        alpha=PAPER_TARGET["alpha_naive"],
        delta=PAPER_TARGET["delta_full"],
    )
    print(f"\n拟合结果:")
    print(f"  β = {fit_result['beta']:.4f} (论文 {PAPER_TARGET['beta_naive']})")
    print(f"  γ = {fit_result['gamma']:.4f} (论文 {PAPER_TARGET['gamma_naive']})")
    print(f"  R₀ = {fit_result['R0']:.3f} (论文 {PAPER_TARGET['R0_naive']})")
    print(f"  R² = {fit_result['R2']:.3f} (论文 {PAPER_TARGET['R2_full']})")
    print(f"  RMSE = {fit_result['RMSE']:.0f} (论文 {PAPER_TARGET['RMSE_full']})")
    print(f"  收敛: {fit_result['converged']}")
    
    dw = durbin_watson(fit_result["residuals"])
    Q20, p20 = ljung_box(fit_result["residuals"], lags=20)
    print(f"  DW = {dw:.3f} (论文 {PAPER_TARGET['DW']})")
    print(f"  Q(20) = {Q20:.2f}, p = {p20:.3f} (论文 22.7, 0.317)")
