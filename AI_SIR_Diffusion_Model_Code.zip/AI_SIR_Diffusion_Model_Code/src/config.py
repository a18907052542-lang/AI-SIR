"""
AI-SIR 跨文化传播实证研究项目全局配置
所有路径、参数、目标值集中于此
"""
import os
from pathlib import Path

# ============= 路径配置 =============
PROJECT_ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = PROJECT_ROOT / "data"
RAW_DIR = DATA_DIR / "raw"
PROCESSED_DIR = DATA_DIR / "processed"
RESULTS_DIR = DATA_DIR / "results"
OUTPUT_DIR = PROJECT_ROOT / "outputs"
FIGURES_DIR = OUTPUT_DIR / "figures"
TABLES_DIR = OUTPUT_DIR / "tables"
REPORTS_DIR = OUTPUT_DIR / "reports"

# 输入数据文件
RAW_VIDEOS_XLSX = RAW_DIR / "AI_SIR_RawData.xlsx"
RAW_COMMENTS_CSV = RAW_DIR / "Comments_Sentiment.csv"
RAW_AI_FEATURES_CSV = RAW_DIR / "AI_Detection_Features.csv"

# 确保所有目录存在
for d in [PROCESSED_DIR, RESULTS_DIR, FIGURES_DIR, TABLES_DIR, REPORTS_DIR]:
    d.mkdir(parents=True, exist_ok=True)

# ============= 时间窗口 =============
import datetime as _dt
OBSERVATION_START = _dt.date(2024, 6, 1)
OBSERVATION_END = _dt.date(2025, 5, 31)
OBSERVATION_DAYS = 365

# ============= AI 检测阈值 =============
AI_DETECTION_THRESHOLD = 0.70   # 主阈值 (GPTZero >= 0.70 标记为 AI)
AI_DETECTION_THRESHOLDS_SENSITIVITY = [0.55, 0.65, 0.70, 0.75, 0.85]  # Table 10

# ============= 恢复状态定义 =============
RECOVERY_INACTIVITY_DAYS = 7         # 主定义
RECOVERY_THRESHOLDS_SENSITIVITY = [3, 5, 7, 10, 14]  # Table 11

# ============= PSM 参数 =============
PSM_CALIPER_SD = 0.05
PSM_COVARIATES = [
    "log_follower_count",
    "account_age_months",
    "posting_freq_per_week",
    "avg_video_duration_sec",
    "dominant_content_type",
    "typical_posting_hour",
    "avg_hashtags_per_video",
]
PSM_SMD_TARGET = 0.10

# ============= 内容类别 =============
CONTENT_CATEGORIES = [
    "Food",
    "Architecture_Scenery",
    "Historical_Humanistic",
    "Philosophy_Cultural_Symbols",
]
CONTENT_CATEGORIES_DISPLAY = {
    "Food": "Food",
    "Architecture_Scenery": "Architecture and Scenery",
    "Historical_Humanistic": "Historical and Humanistic",
    "Philosophy_Cultural_Symbols": "Philosophy and Cultural Symbols",
}

# ============= 区域 =============
AUDIENCE_REGIONS = [
    "English_speaking",
    "East_Asia",
    "Southeast_Asia",
    "Continental_Europe",
    "Latin_America",
    "Middle_East_Others",
]

# ============= 总平台用户数 (N) 估计 =============
# 论文中 S(t) = N - cumulative interactors; N 取 TikTok 海外活跃用户的子集
# 即对中华文明内容潜在感兴趣的用户群规模
N_TOTAL_POPULATION = 100_000   # 海外对中华文化感兴趣的有效用户子集

# ============= 数值方法参数 =============
RK4_STEP_SIZE = 1.0        # 1 天
NLS_METHOD = "trf"         # Trust-Region-Reflective
NLS_MAX_NFEV = 5000
NLS_BOUNDS = ([1e-4, 1e-4], [2.0, 1.0])   # (beta, gamma) bounds

# ============= 论文目标值 (用于对齐验证 / 报告) =============
# Section 4.2.2 主结果 (naive)
PAPER_TARGET = {
    # Table 5 (naive benchmark)
    "beta_naive": 0.129,
    "gamma_naive": 0.057,
    "alpha_naive": 1.465,
    "delta_full": 0.618,
    "R0_naive": 2.051,
    # PSM-adjusted 主结果
    "alpha_psm": 1.32,
    "R0_psm": 1.78,
    # 手工验证 (Section 4.2.1)
    "kappa": 0.81,
    "accuracy": 0.830,
    "precision": 0.860,
    "recall": 0.811,
    "f1": 0.835,
    # 全样本拟合质量 (Section 4.2.2)
    "R2_full": 0.931,
    "RMSE_full": 1247,
    "DW": 1.94,
    "Q20": 22.7,
    "Q20_pval": 0.317,
    "condition_number": 3420,  # 3.42e3
    # 情感分布 (Section 4.3.2)
    "sent_positive": 0.613,
    "sent_neutral": 0.247,
    "sent_negative": 0.140,
    # Cross-validation (Table 9)
    "R2_train": 0.944,
    "R2_val": 0.907,
    "RMSE_train": 1083,
    "RMSE_val": 1561,
    "beta_train": 0.131,
    "beta_val": 0.125,
    "gamma_train": 0.056,
    "gamma_val": 0.060,
    "R0_train": 2.117,
    "R0_val": 1.885,
    # 时间衰减
    "lambda_decay": 0.0031,
    "decay_half_life": 224,
}

# 按内容类型 (Table 6) 论文目标
PAPER_TARGET_BY_CONTENT = {
    "Food":                        {"alpha": 1.512, "delta": 0.738, "beta": 0.141, "gamma": 0.056, "R0": 2.810, "R2": 0.947},
    "Architecture_Scenery":        {"alpha": 1.483, "delta": 0.672, "beta": 0.133, "gamma": 0.058, "R0": 2.286, "R2": 0.938},
    "Historical_Humanistic":       {"alpha": 1.427, "delta": 0.521, "beta": 0.124, "gamma": 0.061, "R0": 1.511, "R2": 0.912},
    "Philosophy_Cultural_Symbols": {"alpha": 1.384, "delta": 0.407, "beta": 0.118, "gamma": 0.064, "R0": 1.040, "R2": 0.889},
}

# 区域 (Table 7) 论文目标
PAPER_TARGET_BY_REGION = {
    "East_Asia":           {"share_non_en": 0.265, "delta": 0.775},
    "Southeast_Asia":      {"share_non_en": 0.324, "delta": 0.686},
    "Continental_Europe":  {"share_non_en": 0.191, "delta": 0.510},
    "Latin_America":       {"share_non_en": 0.132, "delta": 0.452},
    "Middle_East_Others":  {"share_non_en": 0.088, "delta": 0.380},
}

# 情感×内容 (Table 8) 论文目标
PAPER_TARGET_CONTENT_SENT = {
    "Food":                        {"pos_gamma": 0.046, "neg_gamma": 0.067, "increase_pct": 45.7},
    "Architecture_Scenery":        {"pos_gamma": 0.049, "neg_gamma": 0.074, "increase_pct": 51.0},
    "Historical_Humanistic":       {"pos_gamma": 0.053, "neg_gamma": 0.078, "increase_pct": 47.2},
    "Philosophy_Cultural_Symbols": {"pos_gamma": 0.056, "neg_gamma": 0.093, "increase_pct": 66.1},
}

# AI 阈值灵敏度 (Table 10) 论文目标
PAPER_TARGET_AI_THRESHOLD = {
    0.55: {"true_ai_pct": 0.472, "alpha_psm": 1.21, "R0": 1.63},
    0.65: {"true_ai_pct": 0.418, "alpha_psm": 1.27, "R0": 1.71},
    0.70: {"true_ai_pct": 0.366, "alpha_psm": 1.32, "R0": 1.78},
    0.75: {"true_ai_pct": 0.313, "alpha_psm": 1.36, "R0": 1.83},
    0.85: {"true_ai_pct": 0.227, "alpha_psm": 1.41, "R0": 1.90},
}

# 恢复阈值灵敏度 (Table 11) 论文目标
PAPER_TARGET_RECOVERY_THRESHOLD = {
    3:  {"gamma": 0.085, "active_window": 11.8, "R0": 1.19},
    5:  {"gamma": 0.067, "active_window": 14.9, "R0": 1.51},
    7:  {"gamma": 0.057, "active_window": 17.5, "R0": 1.78},
    10: {"gamma": 0.050, "active_window": 20.0, "R0": 2.02},
    14: {"gamma": 0.045, "active_window": 22.2, "R0": 2.25},
}

# Policy exclusion (Table 12) 论文目标
PAPER_TARGET_POLICY_EXCLUSION = {
    "full":     {"alpha": 1.32, "beta": 0.124, "gamma": 0.057, "delta": 0.618, "R0": 1.78},
    "excluded": {"alpha": 1.30, "beta": 0.120, "gamma": 0.060, "delta": 0.618, "R0": 1.61},
}

# Sensitivity (Section 4.3.3): 关键弹性
# γ -20% → R0 +25.0%, γ +20% → R0 -16.7%
# 峰值: γ -20% → +28.6%

# ============= 可视化 =============
FIG_DPI = 150
PLOT_STYLE = "seaborn-v0_8-whitegrid"
COLOR_AI = "#E64B35"
COLOR_HUMAN = "#4DBBD5"
COLOR_FOOD = "#E64B35"
COLOR_ARCH = "#4DBBD5"
COLOR_HIST = "#00A087"
COLOR_PHIL = "#3C5488"

# ============= 随机种子 =============
GLOBAL_SEED = 20240617
