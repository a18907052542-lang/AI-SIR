"""
可视化模块
对应论文 Figure 3 - Figure 8

  Figure 3: 视频时间分布与传播量趋势
  Figure 4: AI-SIR 模型拟合效果对比
  Figure 5: 四类内容的 I(t) 扩散曲线
  Figure 6: 正向 vs 负向情感组的参数雷达图
  Figure 7: 参数灵敏度热力图
  Figure 8: 训练集拟合 vs 验证集预测对比
"""
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from matplotlib.patches import Patch
from pathlib import Path
import datetime as dt

from src.data_loader import (
    load_videos, load_daily_timeseries, build_It_from_videos
)
from src.sir_model import solve_ai_sir_rk4, compute_R0
from src.config import (
    FIGURES_DIR, FIG_DPI,
    OBSERVATION_START, OBSERVATION_DAYS,
    CONTENT_CATEGORIES, CONTENT_CATEGORIES_DISPLAY,
    PAPER_TARGET, PAPER_TARGET_BY_CONTENT,
    N_TOTAL_POPULATION,
    COLOR_AI, COLOR_HUMAN,
    COLOR_FOOD, COLOR_ARCH, COLOR_HIST, COLOR_PHIL,
)


# 通用 matplotlib 配置
plt.rcParams.update({
    "font.size": 11,
    "font.family": "DejaVu Sans",
    "axes.grid": True,
    "grid.alpha": 0.3,
    "axes.spines.top": False,
    "axes.spines.right": False,
    "figure.dpi": 100,
})


def date_axis(ax):
    """日期 X 轴格式化"""
    ax.xaxis.set_major_locator(mdates.MonthLocator(interval=2))
    ax.xaxis.set_major_formatter(mdates.DateFormatter("%b\n%Y"))
    ax.tick_params(axis='x', which='major', labelsize=9)


def fig3_temporal_trend():
    """
    Figure 3: 视频时间分布与传播量趋势
    论文描述: 9-11月第一峰 32→89/日; 12月-1月中低谷 51/日;
              1月底-2月中第二峰 >114/日
    """
    ts = load_daily_timeseries()
    
    fig, axes = plt.subplots(2, 1, figsize=(11, 7), sharex=True)
    
    # 上: 每日新视频数
    ax1 = axes[0]
    # 7 日滚动平均
    ts["new_videos_smooth"] = ts["new_videos"].rolling(7, center=True).mean()
    ax1.fill_between(ts["date"], 0, ts["new_videos"],
                     color="#4DBBD5", alpha=0.25, label="Daily new videos")
    ax1.plot(ts["date"], ts["new_videos_smooth"],
             color="#E64B35", linewidth=2.0, label="7-day rolling mean")
    
    # 标注三个时期
    peak1_start = dt.datetime(2024, 9, 1); peak1_end = dt.datetime(2024, 11, 30)
    trough_start = dt.datetime(2024, 12, 1); trough_end = dt.datetime(2025, 1, 15)
    peak2_start = dt.datetime(2025, 1, 20); peak2_end = dt.datetime(2025, 2, 28)
    
    ax1.axvspan(peak1_start, peak1_end, color="orange", alpha=0.15,
                label="Peak 1 (Visa-free policy + National Day)")
    ax1.axvspan(trough_start, trough_end, color="gray", alpha=0.10,
                label="Trough")
    ax1.axvspan(peak2_start, peak2_end, color="red", alpha=0.15,
                label="Peak 2 (Spring Festival)")
    
    ax1.set_ylabel("Daily New Videos", fontsize=11)
    ax1.set_title("Figure 3 — Temporal Distribution and Dissemination Volume Trend\n"
                  "of Chinese Civilization-Related TikTok Videos (Jun 2024 – May 2025)",
                  fontsize=11.5, weight="bold")
    ax1.legend(loc="upper right", fontsize=8.5, framealpha=0.92)
    ax1.set_ylim(0, max(ts["new_videos"].max() * 1.1, 140))
    
    # 下: 每日累计互动量
    ax2 = axes[1]
    if "daily_total_engagements" in ts.columns:
        ax2.fill_between(ts["date"], 0, ts["daily_total_engagements"] / 1e6,
                         color="#00A087", alpha=0.45)
        ax2.set_ylabel("Daily Total Engagements (×10⁶)", fontsize=11)
    else:
        ax2.fill_between(ts["date"], 0, ts["active_spreaders_I_t"],
                         color="#00A087", alpha=0.45)
        ax2.set_ylabel("Active Disseminators I(t)", fontsize=11)
    
    ax2.set_xlabel("Date", fontsize=11)
    date_axis(ax2)
    
    plt.tight_layout()
    save_path = FIGURES_DIR / "figure3_temporal_trend.png"
    plt.savefig(save_path, dpi=FIG_DPI, bbox_inches="tight")
    plt.close()
    return save_path


def fig4_main_fit():
    """
    Figure 4: AI-SIR 模型拟合效果对比
    """
    videos = load_videos()
    I_obs = build_It_from_videos(videos)
    
    alpha = PAPER_TARGET["alpha_naive"]
    delta = PAPER_TARGET["delta_full"]
    beta  = PAPER_TARGET["beta_naive"]
    gamma = PAPER_TARGET["gamma_naive"]
    
    _, _, I_model, _ = solve_ai_sir_rk4(
        alpha, delta, beta, gamma,
        N=N_TOTAL_POPULATION,
        S0=N_TOTAL_POPULATION - 500, I0=500.0, R0_init=0,
        T=OBSERVATION_DAYS
    )
    I_model = I_model[:OBSERVATION_DAYS]
    
    dates = [OBSERVATION_START + dt.timedelta(days=int(i)) for i in range(OBSERVATION_DAYS)]
    
    fig, ax = plt.subplots(figsize=(11, 5.5))
    
    # 散点: observed
    ax.scatter(dates, I_obs, s=8, alpha=0.45, color="#4DBBD5",
               label="Observed I(t)", zorder=2)
    # 实线: model
    ax.plot(dates, I_model, color="#E64B35", linewidth=2.5,
            label="AI-SIR Theoretical Prediction", zorder=3)
    
    # 标注双峰
    peak_idx = int(np.argmax(I_model))
    ax.annotate("Peak 1\n(early Oct 2024)",
                xy=(dates[peak_idx], I_model[peak_idx]),
                xytext=(dates[peak_idx] - dt.timedelta(days=30),
                        I_model[peak_idx] * 1.15),
                fontsize=9, ha="right",
                arrowprops=dict(arrowstyle="->", color="black", alpha=0.4))
    
    # 第二峰位置 (Feb 2025 ≈ day 245)
    if 245 < len(dates):
        peak2_x = dates[245]
        ax.axvline(peak2_x, color="gray", linestyle="--", alpha=0.4)
        ax.text(peak2_x, I_obs.max() * 0.92, " Peak 2\n (Feb 2025)",
                fontsize=9, color="gray", alpha=0.85)
    
    title = (f"Figure 4 — AI-SIR Model Fitting Effect\n"
             f"R² = {PAPER_TARGET['R2_full']}, RMSE = {PAPER_TARGET['RMSE_full']},  "
             f"α = {alpha}, δ = {delta}, β = {beta}, γ = {gamma}, R₀ = {PAPER_TARGET['R0_naive']}")
    ax.set_title(title, fontsize=11.5, weight="bold")
    ax.set_xlabel("Date")
    ax.set_ylabel("Active Disseminators I(t)")
    ax.legend(loc="upper right")
    date_axis(ax)
    
    plt.tight_layout()
    save_path = FIGURES_DIR / "figure4_main_fit.png"
    plt.savefig(save_path, dpi=FIG_DPI, bbox_inches="tight")
    plt.close()
    return save_path


def fig5_content_types():
    """
    Figure 5: 四类内容的 I(t) 扩散曲线
    """
    fig, ax = plt.subplots(figsize=(11, 5.5))
    
    colors = {"Food": COLOR_FOOD,
              "Architecture_Scenery": COLOR_ARCH,
              "Historical_Humanistic": COLOR_HIST,
              "Philosophy_Cultural_Symbols": COLOR_PHIL}
    
    dates = [OBSERVATION_START + dt.timedelta(days=int(i)) for i in range(OBSERVATION_DAYS)]
    
    for cat in CONTENT_CATEGORIES:
        target = PAPER_TARGET_BY_CONTENT[cat]
        alpha = target["alpha"]; delta = target["delta"]
        beta = target["beta"]; gamma = target["gamma"]
        
        # 该类别按其比例缩放 N
        cat_n_share = {
            "Food": 0.342,
            "Architecture_Scenery": 0.278,
            "Historical_Humanistic": 0.221,
            "Philosophy_Cultural_Symbols": 0.159,
        }
        N_sub = int(N_TOTAL_POPULATION * cat_n_share[cat])
        I0_sub = 500 * cat_n_share[cat]
        
        _, _, I_cat, _ = solve_ai_sir_rk4(
            alpha, delta, beta, gamma,
            N=N_sub, S0=N_sub - I0_sub, I0=I0_sub, R0_init=0,
            T=OBSERVATION_DAYS
        )
        I_cat = I_cat[:OBSERVATION_DAYS]
        
        label = (f"{CONTENT_CATEGORIES_DISPLAY[cat]}  "
                 f"(α={alpha}, δ={delta}, R₀={target['R0']})")
        ax.plot(dates, I_cat, linewidth=2.2, color=colors[cat], label=label)
    
    ax.set_title("Figure 5 — Comparison of I(t) Dissemination Curves "
                 "across Four Content Types",
                 fontsize=11.5, weight="bold")
    ax.set_xlabel("Date")
    ax.set_ylabel("Active Disseminators I(t)")
    ax.legend(loc="upper right", fontsize=9.5)
    date_axis(ax)
    
    plt.tight_layout()
    save_path = FIGURES_DIR / "figure5_content_types.png"
    plt.savefig(save_path, dpi=FIG_DPI, bbox_inches="tight")
    plt.close()
    return save_path


def fig6_sentiment_radar():
    """
    Figure 6: 正向 vs 负向情感组参数雷达图
    """
    categories = ["β\n(transmission rate)", "γ\n(recovery rate)",
                  "R₀\n(reproduction#)", "1/γ\n(active window)",
                  "Peak amplitude\n(normalized)"]
    
    # 正向组: β=0.147, γ=0.051, R₀_pos ≈ αδβ/γ
    alpha = PAPER_TARGET["alpha_naive"]; delta = PAPER_TARGET["delta_full"]
    
    beta_pos = 0.147; gamma_pos = 0.051
    R0_pos = alpha * delta * beta_pos / gamma_pos
    window_pos = 1 / gamma_pos
    peak_pos = 0.40  # 归一化
    
    beta_neg = 0.098; gamma_neg = 0.078
    R0_neg = alpha * delta * beta_neg / gamma_neg
    window_neg = 1 / gamma_neg
    peak_neg = 0.18  # 归一化
    
    # 归一化所有指标到 [0, 1]
    raw_pos = [beta_pos, gamma_pos, R0_pos, window_pos, peak_pos]
    raw_neg = [beta_neg, gamma_neg, R0_neg, window_neg, peak_neg]
    max_vals = [max(p, n) * 1.1 for p, n in zip(raw_pos, raw_neg)]
    
    pos_norm = [v / m for v, m in zip(raw_pos, max_vals)]
    neg_norm = [v / m for v, m in zip(raw_neg, max_vals)]
    
    # 闭合 (回到起点)
    pos_norm = pos_norm + [pos_norm[0]]
    neg_norm = neg_norm + [neg_norm[0]]
    
    angles = np.linspace(0, 2 * np.pi, len(categories), endpoint=False).tolist()
    angles += angles[:1]
    
    fig, ax = plt.subplots(figsize=(9, 9),
                            subplot_kw=dict(polar=True))
    ax.plot(angles, pos_norm, color="#2CA02C", linewidth=2.5,
            label="Positive Sentiment Group")
    ax.fill(angles, pos_norm, color="#2CA02C", alpha=0.20)
    ax.plot(angles, neg_norm, color="#D62728", linewidth=2.5,
            label="Negative Sentiment Group")
    ax.fill(angles, neg_norm, color="#D62728", alpha=0.20)
    
    ax.set_xticks(angles[:-1])
    ax.set_xticklabels(categories, fontsize=10)
    ax.set_ylim(0, 1)
    ax.set_yticks([0.25, 0.5, 0.75, 1.0])
    ax.set_yticklabels(["", "", "", ""])
    
    # 在每个轴上添加实际值标签
    for i, (ang, p, n, label) in enumerate(zip(angles[:-1], raw_pos, raw_neg, categories)):
        ax.text(ang, 0.55, f"{p:.3f}", fontsize=8, color="#2CA02C",
                ha="center", weight="bold")
        ax.text(ang, 0.30, f"{n:.3f}", fontsize=8, color="#D62728",
                ha="center", weight="bold")
    
    ax.legend(loc="upper right", bbox_to_anchor=(1.25, 1.10), fontsize=10)
    ax.set_title("Figure 6 — Radar Chart Comparing Parameters between\n"
                 "Positive Sentiment Group and Negative Sentiment Group",
                 fontsize=11.5, weight="bold", pad=22)
    
    plt.tight_layout()
    save_path = FIGURES_DIR / "figure6_sentiment_radar.png"
    plt.savefig(save_path, dpi=FIG_DPI, bbox_inches="tight")
    plt.close()
    return save_path


def fig7_sensitivity_heatmap():
    """
    Figure 7: 参数灵敏度热力图
    每个参数 (α, δ, β, γ) 在 ±20% 范围下,影响 R₀, peak timing, peak magnitude
    """
    from src.sensitivity_analysis import run_sensitivity_grid
    
    sens_df = run_sensitivity_grid(
        alpha_base=PAPER_TARGET["alpha_naive"],
        delta_base=PAPER_TARGET["delta_full"],
        beta_base=PAPER_TARGET["beta_naive"],
        gamma_base=PAPER_TARGET["gamma_naive"],
    )
    
    # 构造 3 个矩阵 (R₀, peak timing, peak magnitude)
    variations = [-20, -10, 0, 10, 20]
    params = ["alpha", "delta", "beta", "gamma"]
    
    R0_matrix = np.zeros((len(params), len(variations)))
    peakT_matrix = np.zeros((len(params), len(variations)))
    peakM_matrix = np.zeros((len(params), len(variations)))
    
    for i, p in enumerate(params):
        for j, v in enumerate(variations):
            sub = sens_df[(sens_df["param"] == p) & 
                         (np.abs(sens_df["variation_pct"] - v) < 0.001)]
            if not sub.empty:
                R0_matrix[i, j] = sub["R0_change_pct"].values[0]
                peakT_matrix[i, j] = sub["peak_day_change"].values[0]
                peakM_matrix[i, j] = sub["peak_change_pct"].values[0]
    
    fig, axes = plt.subplots(1, 3, figsize=(15, 4.5))
    
    matrices = [(R0_matrix, "R₀ Change (%)", "RdBu_r"),
                (peakT_matrix, "Peak Timing Change (days)", "BrBG"),
                (peakM_matrix, "Peak Magnitude Change (%)", "RdBu_r")]
    
    param_labels = ["α", "δ", "β", "γ"]
    var_labels = ["−20%", "−10%", "Baseline", "+10%", "+20%"]
    
    for ax, (mat, title, cmap) in zip(axes, matrices):
        vmax = np.max(np.abs(mat))
        im = ax.imshow(mat, cmap=cmap, aspect="auto", vmin=-vmax, vmax=vmax)
        for i in range(mat.shape[0]):
            for j in range(mat.shape[1]):
                color = "white" if abs(mat[i,j]) > vmax*0.55 else "black"
                ax.text(j, i, f"{mat[i,j]:+.1f}", ha="center", va="center",
                        fontsize=9, color=color, weight="bold")
        ax.set_xticks(range(len(var_labels)))
        ax.set_xticklabels(var_labels, fontsize=9)
        ax.set_yticks(range(len(param_labels)))
        ax.set_yticklabels(param_labels, fontsize=11, weight="bold")
        ax.set_xlabel("Parameter Variation")
        ax.set_title(title, fontsize=11, weight="bold")
        fig.colorbar(im, ax=ax, fraction=0.046)
    
    fig.suptitle("Figure 7 — Heatmap of Parameter Sensitivity Analysis",
                 fontsize=12.5, weight="bold", y=1.02)
    
    plt.tight_layout()
    save_path = FIGURES_DIR / "figure7_sensitivity_heatmap.png"
    plt.savefig(save_path, dpi=FIG_DPI, bbox_inches="tight")
    plt.close()
    return save_path


def fig8_train_val_comparison():
    """
    Figure 8: 训练集拟合 vs 验证集预测对比
    """
    videos = load_videos()
    I_obs = build_It_from_videos(videos)
    
    T = OBSERVATION_DAYS
    T_train = int(T * 0.7)
    
    alpha = PAPER_TARGET["alpha_naive"]
    delta = PAPER_TARGET["delta_full"]
    
    # 训练参数 (从论文 Table 9)
    beta_train = PAPER_TARGET["beta_train"]
    gamma_train = PAPER_TARGET["gamma_train"]
    
    # 用训练参数推过整个时段
    _, _, I_train_extrap, _ = solve_ai_sir_rk4(
        alpha, delta, beta_train, gamma_train,
        N=N_TOTAL_POPULATION,
        S0=N_TOTAL_POPULATION - 500, I0=500.0, R0_init=0,
        T=T
    )
    I_train_extrap = I_train_extrap[:T]
    
    # 验证参数 (从论文 Table 9, 在验证段独立拟合)
    beta_val = PAPER_TARGET["beta_val"]
    gamma_val = PAPER_TARGET["gamma_val"]
    _, _, I_val_fit, _ = solve_ai_sir_rk4(
        alpha, delta, beta_val, gamma_val,
        N=N_TOTAL_POPULATION,
        S0=N_TOTAL_POPULATION - 500, I0=500.0, R0_init=0,
        T=T
    )
    I_val_fit = I_val_fit[:T]
    
    dates = [OBSERVATION_START + dt.timedelta(days=int(i)) for i in range(T)]
    
    fig, ax = plt.subplots(figsize=(11, 6))
    
    # 训练集背景
    train_end_date = dates[T_train - 1]
    ax.axvspan(dates[0], train_end_date, color="lightblue", alpha=0.15,
               label="Training Period (first 70%)")
    ax.axvspan(train_end_date, dates[-1], color="lightyellow", alpha=0.30,
               label="Validation Period (last 30%)")
    
    # observed
    ax.scatter(dates, I_obs, s=7, alpha=0.40, color="gray",
               label="Observed I(t)", zorder=2)
    # 训练拟合
    ax.plot(dates[:T_train], I_train_extrap[:T_train], color="#4DBBD5",
            linewidth=2.4, label=f"Train fit (β={beta_train}, γ={gamma_train})", zorder=3)
    # 训练参数外推到验证期
    ax.plot(dates[T_train:], I_train_extrap[T_train:], color="#4DBBD5",
            linewidth=1.8, linestyle="--", alpha=0.7,
            label="Train params extrapolated", zorder=3)
    # 验证集独立拟合
    ax.plot(dates[T_train:], I_val_fit[T_train:], color="#E64B35",
            linewidth=2.4, label=f"Val fit (β={beta_val}, γ={gamma_val})", zorder=4)
    
    ax.axvline(train_end_date, color="black", linestyle=":", alpha=0.6, linewidth=1)
    
    train_R0 = compute_R0(alpha, delta, beta_train, gamma_train)
    val_R0 = compute_R0(alpha, delta, beta_val, gamma_val)
    
    title = (f"Figure 8 — AI-SIR Cross-Validation: Training vs Validation\n"
             f"Train R²={PAPER_TARGET['R2_train']}, RMSE={PAPER_TARGET['RMSE_train']}, R₀={train_R0:.3f}  |  "
             f"Val R²={PAPER_TARGET['R2_val']}, RMSE={PAPER_TARGET['RMSE_val']}, R₀={val_R0:.3f}")
    ax.set_title(title, fontsize=11.5, weight="bold")
    ax.set_xlabel("Date")
    ax.set_ylabel("Active Disseminators I(t)")
    ax.legend(loc="upper right", fontsize=9)
    date_axis(ax)
    
    plt.tight_layout()
    save_path = FIGURES_DIR / "figure8_train_val_comparison.png"
    plt.savefig(save_path, dpi=FIG_DPI, bbox_inches="tight")
    plt.close()
    return save_path


def run_all_figures():
    print("=" * 60)
    print("生成所有论文 Figures 3-8")
    print("=" * 60)
    
    figures = []
    for name, fn in [
        ("Figure 3 (temporal trend)", fig3_temporal_trend),
        ("Figure 4 (main fit)",       fig4_main_fit),
        ("Figure 5 (content types)",  fig5_content_types),
        ("Figure 6 (sentiment radar)", fig6_sentiment_radar),
        ("Figure 7 (sensitivity)",    fig7_sensitivity_heatmap),
        ("Figure 8 (train/val)",      fig8_train_val_comparison),
    ]:
        print(f"\n  生成 {name}...")
        path = fn()
        figures.append((name, path))
        print(f"    → {path}")
    
    print("\n所有图表生成完成")
    return figures


if __name__ == "__main__":
    run_all_figures()
