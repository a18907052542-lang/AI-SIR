"""
AI-SIR 动力学模型
对应论文 Section 3.2 公式 (1)-(3)

经典 SIR:
    dS/dt = -β SI/N
    dI/dt =  β SI/N - γI
    dR/dt =  γI

AI-SIR (公式 2):
    dS/dt = -α·δ·β·SI/N
    dI/dt =  α·δ·β·SI/N - γI
    dR/dt =  γI

基本再生数 (公式 3):
    R0 = α·δ·β / γ

数值求解:四阶 Runge-Kutta 法 (RK4),步长 h=1 天,截断误差 O(h^5)
"""
import numpy as np
from scipy.integrate import solve_ivp


def ai_sir_rhs(t, y, alpha, delta, beta, gamma, N):
    """
    AI-SIR 模型右端项 (公式 2)
    
    参数
    ----
    t : float, 时间
    y : ndarray (3,), [S, I, R]
    alpha : AI 放大系数 (α > 1)
    delta : 文化折扣因子 (0 < δ < 1)
    beta  : 基础传播率
    gamma : 恢复率
    N : 总人口规模
    """
    S, I, R = y
    new_infections = alpha * delta * beta * S * I / N
    recoveries = gamma * I
    
    dS_dt = -new_infections
    dI_dt = new_infections - recoveries
    dR_dt = recoveries
    return [dS_dt, dI_dt, dR_dt]


def rk4_step(f, t, y, h, args):
    """
    四阶 Runge-Kutta 单步
    对应论文 Section 3.6: "fourth-order Runge-Kutta method,
    weighted average of four slope values, truncation error O(h^5)"
    """
    k1 = np.array(f(t,         y,             *args))
    k2 = np.array(f(t + h/2,   y + h/2 * k1,  *args))
    k3 = np.array(f(t + h/2,   y + h/2 * k2,  *args))
    k4 = np.array(f(t + h,     y + h   * k3,  *args))
    return y + h/6 * (k1 + 2*k2 + 2*k3 + k4)


def solve_ai_sir_rk4(alpha, delta, beta, gamma, N, S0, I0, R0_init, T, h=1.0):
    """
    用 RK4 方法求解 AI-SIR 系统
    
    参数
    ----
    alpha, delta, beta, gamma : 模型参数
    N : 总人口
    S0, I0, R0_init : 初始条件
    T : 时间长度 (天)
    h : 步长 (默认 1 天)
    
    返回
    ----
    t_arr, S_arr, I_arr, R_arr : 时间序列
    """
    n_steps = int(T / h)
    t_arr = np.zeros(n_steps + 1)
    S_arr = np.zeros(n_steps + 1)
    I_arr = np.zeros(n_steps + 1)
    R_arr = np.zeros(n_steps + 1)
    
    t_arr[0] = 0
    S_arr[0] = S0
    I_arr[0] = I0
    R_arr[0] = R0_init
    
    y = np.array([S0, I0, R0_init], dtype=float)
    args = (alpha, delta, beta, gamma, N)
    
    for k in range(n_steps):
        y = rk4_step(ai_sir_rhs, t_arr[k], y, h, args)
        y = np.maximum(y, 0.0)  # 防止数值误差导致负值
        t_arr[k+1] = t_arr[k] + h
        S_arr[k+1] = y[0]
        I_arr[k+1] = y[1]
        R_arr[k+1] = y[2]
    
    return t_arr, S_arr, I_arr, R_arr


def solve_ai_sir_scipy(alpha, delta, beta, gamma, N, S0, I0, R0_init, T):
    """
    用 scipy.integrate.solve_ivp 求解 (论文 Section 3.6 备选方法)
    """
    sol = solve_ivp(
        ai_sir_rhs,
        t_span=(0, T),
        y0=[S0, I0, R0_init],
        args=(alpha, delta, beta, gamma, N),
        method="RK45",
        t_eval=np.arange(T+1),
        rtol=1e-6,
        atol=1e-8,
    )
    return sol.t, sol.y[0], sol.y[1], sol.y[2]


def compute_R0(alpha, delta, beta, gamma):
    """
    AI-SIR 基本再生数 (公式 3)
    R0 = α·δ·β / γ
    """
    return (alpha * delta * beta) / gamma


def compute_R0_classical(beta, gamma):
    """经典 SIR 的 R0 = β/γ"""
    return beta / gamma


def find_peak(I_arr):
    """寻找 I(t) 峰值时点与峰值大小"""
    peak_idx = int(np.argmax(I_arr))
    peak_val = float(I_arr[peak_idx])
    return peak_idx, peak_val


if __name__ == "__main__":
    # 自检:用论文 Section 4.2.2 主参数求解,验证 R0
    from src.config import PAPER_TARGET, N_TOTAL_POPULATION
    
    alpha = PAPER_TARGET["alpha_naive"]
    delta = PAPER_TARGET["delta_full"]
    beta  = PAPER_TARGET["beta_naive"]
    gamma = PAPER_TARGET["gamma_naive"]
    
    print(f"参数: α={alpha}, δ={delta}, β={beta}, γ={gamma}")
    print(f"理论 R0 = α·δ·β/γ = {compute_R0(alpha, delta, beta, gamma):.4f}")
    print(f"论文 R0 (naive) = {PAPER_TARGET['R0_naive']}")
    
    # 求解 1 年
    N = N_TOTAL_POPULATION
    I0 = 1000  # 初始活跃传播者
    S0 = N - I0
    R0_init = 0
    T = 365
    
    t, S, I, R = solve_ai_sir_rk4(alpha, delta, beta, gamma, N, S0, I0, R0_init, T)
    peak_idx, peak_val = find_peak(I)
    print(f"\nRK4 求解 1 年:")
    print(f"  I(t) 峰值: {peak_val:.0f}, 时点: 第 {peak_idx} 天")
    print(f"  最终 R(T) = {R[-1]:.0f}, S(T) = {S[-1]:.0f}")
    print(f"  S+I+R 守恒检验: {S[-1]+I[-1]+R[-1]:.0f} (应等于 N={N})")
